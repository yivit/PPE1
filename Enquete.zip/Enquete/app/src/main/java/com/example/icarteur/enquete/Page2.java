package com.example.icarteur.enquete;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Page2 extends AppCompatActivity {

    private String nom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        this.nom = getIntent().getStringExtra("nom");

        Toast.makeText(this, "Bienvenue : "+this.nom, Toast.LENGTH_SHORT).show();



    }
}
