package com.example.icarteur.enquete;

import java.util.HashMap;

/**
 * Created by Icarteur on 09/02/2018.
 */

public class Enquete {

    private static HashMap<String, Candidat> lesCandidats = new HashMap<String, Candidat>();


    public static void ajouterCandidat (Candidat unCandidat){

        Enquete.lesCandidats.put(unCandidat.getNom(), unCandidat);

    }

    public static void ajouterReponse (String nom, String question, int score){

        Enquete.lesCandidats.get(nom).ajouterReponse(question,score);

    }

    public static float getLaMoyenneCandidat (String nom){

        return Enquete.lesCandidats.get(nom).getMoyenne();
    }

    public static String getImagesSmileyCandidat (String nom, String generique){

        return Enquete.lesCandidats.get(nom).getImageSmiley(generique);

    }
}
