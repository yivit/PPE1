package com.example.icarteur.enquete;

import java.util.HashMap;

/**
 * Created by Icarteur on 09/02/2018.
 */

public class Candidat {


    private String nom, prenom, classe, annee;
    private HashMap<String, Integer> lesReponses;

    public Candidat (String nom, String personne, String classe, String annee){



        this.nom = nom;
        this.prenom = prenom;
        this.classe = classe;
        this.annee = annee;
        this.lesReponses = new HashMap<String, Integer>();

    }

    public void ajouterReponse (String question, int score){

        this.lesReponses.put(question, score);

    }

    public float getMoyenne(){

        float moyenne = 0;

        for (Integer score : this.lesReponses.values()) {

            moyenne += score;

        }

        moyenne /= this.lesReponses.size();
        return moyenne;
    }

    public String getImageSmiley(String generique){

        if (this.getMoyenne() < 8 )
            return generique +"1.png";
        else if (this.getMoyenne() < 14)
            return generique +"2.png";
        else return generique + "3.png";

    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
}
