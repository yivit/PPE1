package com.example.icarteur.enquete;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText txtNom, txtPrenom;
    private Spinner spClasse, spAnnee;
    private Button btSuivant;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        this.btSuivant = (Button) findViewById(R.id.button);

        this.spAnnee = (Spinner) findViewById(R.id.spinner2);
        this.spClasse = (Spinner) findViewById(R.id.spinner1);

        this.txtNom = (EditText) findViewById(R.id.SaisieNom);
        this.txtPrenom = (EditText) findViewById(R.id.SaisiePrenom);


        ArrayList<String> lesClasses = new ArrayList<String>();
        lesClasses.add("BTS SIO SLAM");
        lesClasses.add("BTS SIO SISR");
        lesClasses.add("DEES WEB");
        lesClasses.add("DEES DESIR");
        lesClasses.add("Master I");


        ArrayList<String> lesAnnees = new ArrayList<String>();
        lesAnnees.add("2018");
        lesAnnees.add("2017");
        lesAnnees.add("2016");
        lesAnnees.add("2015");
        lesAnnees.add("2014");

        ArrayAdapter unAdaptateur = new ArrayAdapter(this, android.R.layout.simple_spinner_item, lesClasses);
        this.spClasse.setAdapter(unAdaptateur);


        ArrayAdapter unAdaptateur2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, lesAnnees);
        this.spAnnee.setAdapter(unAdaptateur2);

        this.btSuivant.setOnClickListener(this);



    }

    @Override
    public void onClick(View view) {


        String nom = this.txtNom.getText().toString();
        String prenom = this.txtPrenom.getText().toString();
        String classe = this.spClasse.getSelectedItem().toString();
        String annee = this.spAnnee.getSelectedItem().toString();

        //Instanciation d'in candidat
        Candidat unCandidat = new Candidat(nom, prenom, classe, annee);
        //On ajoute a la Hashmap
        Enquete.ajouterCandidat(unCandidat);

        //on passe a la page 2
        Intent unItent = new Intent( this, Page2.class);

        unItent.putExtra("nom", nom);
        startActivity(unItent);

    }
}
